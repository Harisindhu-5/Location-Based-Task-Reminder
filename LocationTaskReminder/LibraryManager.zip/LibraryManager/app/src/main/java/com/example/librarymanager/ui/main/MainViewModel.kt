package com.example.librarymanager.ui.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.librarymanager.data.model.Book
import com.example.librarymanager.data.model.BookStatus
import com.example.librarymanager.data.repository.BookRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Date

class MainViewModel(val repository: BookRepository) : ViewModel() {
    private val _currentStatus = MutableStateFlow(BookStatus.TO_READ)
    val currentStatus: StateFlow<BookStatus> = _currentStatus.asStateFlow()

    private val _books = MutableStateFlow<List<Book>>(emptyList())
    val books: StateFlow<List<Book>> = _books.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private var currentSortOrder = SortOrder.DATE_ADDED

    init {
        loadBooks()
    }

    fun setCurrentStatus(status: BookStatus) {
        _currentStatus.value = status
        loadBooks()
    }

    private fun loadBooks() {
        viewModelScope.launch {
            try {
                repository.getBooksByStatus(_currentStatus.value).collect { books ->
                    _books.value = sortBooks(books)
                }
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun setSortOrder(sortOrder: SortOrder) {
        currentSortOrder = sortOrder
        _books.value = sortBooks(_books.value)
    }

    private fun sortBooks(books: List<Book>): List<Book> {
        return when (currentSortOrder) {
            SortOrder.TITLE -> books.sortedBy { it.title }
            SortOrder.AUTHOR -> books.sortedBy { it.author }
            SortOrder.DATE_ADDED -> books.sortedByDescending { it.addedDate }
            SortOrder.DUE_DATE -> books.sortedBy { it.dueDate }
        }
    }

    fun addBook(book: Book) {
        viewModelScope.launch {
            try {
                repository.insertBook(book)
                loadBooks()
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun updateBook(book: Book) {
        viewModelScope.launch {
            try {
                repository.updateBook(book)
                loadBooks()
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun deleteBook(book: Book) {
        viewModelScope.launch {
            try {
                repository.deleteBook(book)
                loadBooks()
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun searchBooks(query: String) {
        viewModelScope.launch {
            try {
                repository.searchBooks(query).collect { books ->
                    _books.value = sortBooks(books)
                }
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }

    fun getBooksWithDueDate(currentDate: Date) {
        viewModelScope.launch {
            try {
                repository.getBooksWithDueDate(currentDate).collect { books ->
                    _books.value = sortBooks(books)
                }
            } catch (e: Exception) {
                _error.value = e.message
            }
        }
    }
}

enum class SortOrder {
    TITLE,
    AUTHOR,
    DATE_ADDED,
    DUE_DATE
} 