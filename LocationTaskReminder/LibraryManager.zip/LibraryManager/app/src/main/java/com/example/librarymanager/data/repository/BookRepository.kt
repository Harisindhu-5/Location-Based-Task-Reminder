package com.example.librarymanager.data.repository

import com.example.librarymanager.data.local.BookDao
import com.example.librarymanager.data.model.Book
import com.example.librarymanager.data.model.BookStatus
import kotlinx.coroutines.flow.Flow
import java.util.Date

class BookRepository(private val bookDao: BookDao) {
    fun getAllBooks(): Flow<List<Book>> = bookDao.getAllBooks()

    fun getBooksByStatus(status: BookStatus): Flow<List<Book>> = bookDao.getBooksByStatus(status)

    suspend fun getBookById(bookId: Long): Book? = bookDao.getBookById(bookId)

    suspend fun insertBook(book: Book): Long = bookDao.insertBook(book)

    suspend fun updateBook(book: Book) = bookDao.updateBook(book)

    suspend fun deleteBook(book: Book) = bookDao.deleteBook(book)

    fun searchBooks(query: String): Flow<List<Book>> = bookDao.searchBooks(query)

    fun getBooksWithDueDate(currentDate: Date): Flow<List<Book>> = bookDao.getBooksWithDueDate(currentDate)
} 