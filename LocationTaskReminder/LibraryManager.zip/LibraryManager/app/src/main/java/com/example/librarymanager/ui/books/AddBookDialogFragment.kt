package com.example.librarymanager.ui.books

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.example.librarymanager.MainActivity
import com.example.librarymanager.R
import com.example.librarymanager.data.model.Book
import com.example.librarymanager.data.model.BookStatus
import com.example.librarymanager.databinding.DialogAddBookBinding
import com.example.librarymanager.ui.main.MainViewModel
import com.example.librarymanager.ui.main.MainViewModelFactory
import com.google.android.material.datepicker.MaterialDatePicker
import java.text.SimpleDateFormat
import java.util.*

class AddBookDialogFragment : DialogFragment() {
    private var _binding: DialogAddBookBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels(
        factoryProducer = {
            val repository = (requireActivity() as MainActivity).getRepository()
            MainViewModelFactory(repository)
        }
    )
    private var selectedDueDate: Date? = null
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogAddBookBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.dueDateEditText.setOnClickListener {
            showDatePicker()
        }

        binding.dueDateTextInputLayout.setEndIconOnClickListener {
            showDatePicker()
        }

        binding.saveButton.setOnClickListener {
            val title = binding.titleEditText.text.toString()
            val author = binding.authorEditText.text.toString()
            val description = binding.descriptionEditText.text.toString()
            val isbn = binding.isbnEditText.text.toString()
            val totalPages = binding.totalPagesEditText.text.toString().toIntOrNull() ?: 0
            val dueDate = selectedDueDate

            if (title.isBlank() || author.isBlank() || dueDate == null) {
                Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val book = Book(
                title = title,
                author = author,
                description = description,
                isbn = isbn,
                totalPages = totalPages,
                addedDate = Date(),
                status = viewModel.currentStatus.value ?: BookStatus.TO_READ,
                dueDate = dueDate
            )

            viewModel.addBook(book)
            dismiss()
        }

        binding.cancelButton.setOnClickListener {
            dismiss()
        }
    }

    private fun showDatePicker() {
        val datePicker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Select Due Date")
            .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
            .build()

        datePicker.addOnPositiveButtonClickListener { selection ->
            selectedDueDate = Date(selection)
            updateDueDateText()
        }

        datePicker.show(childFragmentManager, "DATE_PICKER")
    }

    private fun updateDueDateText() {
        selectedDueDate?.let { date ->
            binding.dueDateEditText.setText(dateFormat.format(date))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        const val TAG = "AddBookDialogFragment"
    }
} 