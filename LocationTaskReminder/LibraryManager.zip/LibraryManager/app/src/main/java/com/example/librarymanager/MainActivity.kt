package com.example.librarymanager

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import androidx.work.*
import com.example.librarymanager.data.local.BookDatabase
import com.example.librarymanager.data.model.BookStatus
import com.example.librarymanager.data.repository.BookRepository
import com.example.librarymanager.databinding.ActivityMainBinding
import com.example.librarymanager.notification.ReadingGoalNotificationManager
import com.example.librarymanager.service.ReadingProgressService
import com.example.librarymanager.ui.books.AddBookDialogFragment
import com.example.librarymanager.ui.books.BookListFragment
import com.example.librarymanager.ui.main.MainViewModel
import com.example.librarymanager.ui.main.MainViewModelFactory
import com.example.librarymanager.ui.main.SortOrder
import com.example.librarymanager.worker.DueDateCheckWorker
import com.google.android.material.tabs.TabLayoutMediator
import java.util.Date
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var readingGoalNotificationManager: ReadingGoalNotificationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val bookDao = BookDatabase.getDatabase(this).bookDao()
        val repository = BookRepository(bookDao)
        val factory = MainViewModelFactory(repository)
        viewModel = ViewModelProvider(this, factory)[MainViewModel::class.java]
        readingGoalNotificationManager = ReadingGoalNotificationManager(this)

        setupViewPager()
        setupFab()
        startReadingProgressService()
        scheduleDueDateChecks()
    }

    private fun scheduleDueDateChecks() {
        val workManager = WorkManager.getInstance(applicationContext)
        
        // Create constraints that require the device to be charging and have network connectivity
        val constraints = Constraints.Builder()
            .setRequiresCharging(false)
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        // Schedule daily due date checks
        val dueDateCheckRequest = PeriodicWorkRequestBuilder<DueDateCheckWorker>(
            1, TimeUnit.DAYS
        )
        .setConstraints(constraints)
        .build()

        // Enqueue unique periodic work
        workManager.enqueueUniquePeriodicWork(
            "due_date_check",
            ExistingPeriodicWorkPolicy.KEEP,
            dueDateCheckRequest
        )
    }

    private fun startReadingProgressService() {
        startService(android.content.Intent(this, ReadingProgressService::class.java))
    }

    private fun setupViewPager() {
        binding.viewPager.adapter = BookPagerAdapter(this)

        TabLayoutMediator(binding.tabLayout, binding.viewPager) { tab, position ->
            tab.text = when (position) {
                0 -> getString(R.string.to_read)
                1 -> getString(R.string.reading)
                2 -> getString(R.string.read)
                3 -> getString(R.string.wishlist)
                else -> throw IllegalArgumentException("Invalid position: $position")
            }
        }.attach()

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                val status = when (position) {
                    0 -> BookStatus.TO_READ
                    1 -> BookStatus.READING
                    2 -> BookStatus.READ
                    3 -> BookStatus.WISHLIST
                    else -> BookStatus.TO_READ
                }
                viewModel.setCurrentStatus(status)
            }
        })
    }

    private fun setupFab() {
        binding.fabAddBook.setOnClickListener {
            AddBookDialogFragment().show(supportFragmentManager, AddBookDialogFragment.TAG)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as androidx.appcompat.widget.SearchView
        searchView.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { viewModel.searchBooks(it) }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let { viewModel.searchBooks(it) }
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.sort_title -> {
                viewModel.setSortOrder(SortOrder.TITLE)
                true
            }
            R.id.sort_author -> {
                viewModel.setSortOrder(SortOrder.AUTHOR)
                true
            }
            R.id.sort_date_added -> {
                viewModel.setSortOrder(SortOrder.DATE_ADDED)
                true
            }
            R.id.sort_due_date -> {
                viewModel.setSortOrder(SortOrder.DUE_DATE)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private inner class BookPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
        override fun getItemCount(): Int = 4

        override fun createFragment(position: Int): Fragment {
            return BookListFragment().apply {
                arguments = Bundle().apply {
                    putInt("position", position)
                }
            }
        }
    }

    fun getRepository(): BookRepository = viewModel.repository
}