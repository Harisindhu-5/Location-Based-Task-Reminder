package com.example.librarymanager.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import com.example.librarymanager.R
import java.util.concurrent.TimeUnit

class ReadingGoalNotificationManager(private val context: Context) {
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
        scheduleReadingGoalChecks()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Reading Goals",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications about reading goals"
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun scheduleReadingGoalChecks() {
        val workManager = WorkManager.getInstance(context)
        val readingGoalCheckRequest = PeriodicWorkRequestBuilder<ReadingGoalWorker>(
            1, TimeUnit.DAYS
        ).build()

        workManager.enqueueUniquePeriodicWork(
            "reading_goal_check",
            ExistingPeriodicWorkPolicy.KEEP,
            readingGoalCheckRequest
        )
    }

    fun showReadingGoalNotification(booksRead: Int, goalBooks: Int) {
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Reading Goal Progress")
            .setContentText("You've read $booksRead out of $goalBooks books")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    companion object {
        private const val CHANNEL_ID = "reading_goals_channel"
        private const val NOTIFICATION_ID = 1001
    }
}

class ReadingGoalWorker(
    private val context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        // TODO: Check reading goals and show notifications
        return Result.success()
    }
} 