package com.example.librarymanager.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.librarymanager.R
import com.example.librarymanager.data.local.BookDatabase
import com.example.librarymanager.data.repository.BookRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.Date

class DueDateReceiver : BroadcastReceiver() {
    private val CHANNEL_ID = "due_date_channel"
    private val NOTIFICATION_ID = 2

    override fun onReceive(context: Context, intent: Intent) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel(context, notificationManager)

        // Initialize repository
        val bookDao = BookDatabase.getDatabase(context).bookDao()
        val repository = BookRepository(bookDao)

        // Check for books due today
        CoroutineScope(Dispatchers.IO).launch {
            repository.getBooksWithDueDate(Date()).firstOrNull()?.let { books ->
                if (books.isNotEmpty()) {
                    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                        .setSmallIcon(R.drawable.ic_notification)
                        .setContentTitle("Books Due Today")
                        .setContentText("You have ${books.size} book(s) due today")
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setAutoCancel(true)
                        .build()

                    notificationManager.notify(NOTIFICATION_ID, notification)
                }
            }
        }
    }

    private fun createNotificationChannel(context: Context, notificationManager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Due Date Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for book due dates"
            }
            notificationManager.createNotificationChannel(channel)
        }
    }
} 