package com.example.librarymanager.provider

import android.content.*
import android.database.Cursor
import android.net.Uri
import com.example.librarymanager.data.local.BookDatabase
import com.example.librarymanager.data.model.Book

class BookContentProvider : ContentProvider() {
    private lateinit var database: BookDatabase

    override fun onCreate(): Boolean {
        database = BookDatabase.getDatabase(context!!)
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<String>?,
        selection: String?,
        selectionArgs: Array<String>?,
        sortOrder: String?
    ): Cursor? {
        val cursor = when (uri.lastPathSegment) {
            "books" -> database.bookDao().getAllBooksAsCursor()
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        cursor?.setNotificationUri(context?.contentResolver, uri)
        return cursor
    }

    override fun getType(uri: Uri): String = when (uri.lastPathSegment) {
        "books" -> "vnd.android.cursor.dir/vnd.com.example.librarymanager.books"
        else -> throw IllegalArgumentException("Unknown URI: $uri")
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        throw UnsupportedOperationException("Insert operation not supported")
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        throw UnsupportedOperationException("Delete operation not supported")
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        throw UnsupportedOperationException("Update operation not supported")
    }

    companion object {
        private const val AUTHORITY = "com.example.librarymanager.provider"
        val CONTENT_URI: Uri = Uri.parse("content://$AUTHORITY/books")
    }
} 