package com.example.librarymanager.data.local

import android.database.Cursor
import androidx.room.*
import com.example.librarymanager.data.model.Book
import com.example.librarymanager.data.model.BookStatus
import kotlinx.coroutines.flow.Flow
import java.util.*

@Dao
interface BookDao {
    @Query("SELECT * FROM books ORDER BY addedDate DESC")
    fun getAllBooks(): Flow<List<Book>>

    @Query("SELECT * FROM books ORDER BY addedDate DESC")
    fun getAllBooksAsCursor(): Cursor

    @Query("SELECT * FROM books WHERE status = :status ORDER BY addedDate DESC")
    fun getBooksByStatus(status: BookStatus): Flow<List<Book>>

    @Query("SELECT * FROM books WHERE id = :bookId")
    suspend fun getBookById(bookId: Long): Book?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: Book): Long

    @Update
    suspend fun updateBook(book: Book)

    @Delete
    suspend fun deleteBook(book: Book)

    @Query("SELECT * FROM books WHERE title LIKE '%' || :query || '%' OR author LIKE '%' || :query || '%'")
    fun searchBooks(query: String): Flow<List<Book>>

    @Query("SELECT * FROM books WHERE dueDate IS NOT NULL AND dueDate <= :currentDate ORDER BY dueDate ASC")
    fun getBooksWithDueDate(currentDate: Date): Flow<List<Book>>
} 