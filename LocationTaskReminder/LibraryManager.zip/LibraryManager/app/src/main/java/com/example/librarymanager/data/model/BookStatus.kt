package com.example.librarymanager.data.model

enum class BookStatus {
    TO_READ,
    READING,
    READ,
    WISHLIST
} 