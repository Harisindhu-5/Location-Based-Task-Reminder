package com.example.librarymanager.ui.main

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.librarymanager.data.model.BookStatus
import com.example.librarymanager.ui.books.BookListFragment

class BookPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int = 4

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> BookListFragment.newInstance(BookStatus.TO_READ)
            1 -> BookListFragment.newInstance(BookStatus.READING)
            2 -> BookListFragment.newInstance(BookStatus.READ)
            3 -> BookListFragment.newInstance(BookStatus.WISHLIST)
            else -> throw IllegalArgumentException("Invalid position: $position")
        }
    }
} 