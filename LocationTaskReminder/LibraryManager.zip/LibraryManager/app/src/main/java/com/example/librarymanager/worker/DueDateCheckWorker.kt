package com.example.librarymanager.worker

import android.content.Context
import android.content.Intent
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.librarymanager.receiver.DueDateReceiver

class DueDateCheckWorker(
    private val context: Context,
    params: WorkerParameters
) : Worker(context, params) {

    override fun doWork(): Result {
        // Trigger the DueDateReceiver
        val intent = Intent(context, DueDateReceiver::class.java)
        context.sendBroadcast(intent)
        return Result.success()
    }
} 