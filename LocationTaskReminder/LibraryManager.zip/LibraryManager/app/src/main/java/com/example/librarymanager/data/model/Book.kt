package com.example.librarymanager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "books")
data class Book(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val author: String,
    val description: String,
    val coverImageUrl: String? = null,
    val isbn: String? = null,
    val publishDate: Date? = null,
    val addedDate: Date = Date(),
    val dueDate: Date? = null,
    val status: BookStatus = BookStatus.TO_READ,
    val currentPage: Int = 0,
    val totalPages: Int? = null,
    val rating: Float? = null,
    val notes: String? = null
) 